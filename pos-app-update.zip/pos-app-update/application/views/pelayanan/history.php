<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="flashdata" data-flashdata="<?= $this->session->flashdata('pesan'); ?>"></div>

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
  </div>

  <div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
      <h6 class="m-0 font-weight-bold text-primary">Data <?= $title ?></h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr class="bg-primary text-white">
              <th>#</th>
              <th>ID Member</th>
              <th>Nama</th>
              <th>Barber</th>
              <th>Tagihan</th>
              <th>Bayar</th>
              <th>Check Out</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <!-- <tfoot>
            <tr class="bg-primary text-white">
              <th>No</th>
              <th>ID Member</th>
              <th>Nama</th>
              <th>Nomor HP</th>
              <th>Instagram</th>
              <th>Jenis Pelanggan</th>
              <th>Aksi</th>
            </tr>
          </tfoot> -->
          <tbody>
            <?php $i = 1; ?>
            <?php foreach ($pelanggan as $p) : ?>
              <tr>
                <th><?= $i++ ?></th>
                <td><?= $p['id_pelanggan'] ?></td>
                <td><?= $p['nama_pelanggan'] ?></td>
                <td><?= $p['nama_barber'] ?></td>
                <td><?= $p['tagihan'] ?></td>
                <td><?= $p['bayar'] ?></td>
                <td><?= $p['check_out'] ?></td>
                <td>
                  <a href="<?= site_url('pelayanan/history_detail/' . $p['id_kunjungan'] . '') ?>" class="btn btn-primary btn-sm">Detail</a>
                  <a href="https://wa.me/+62<?= $p['nohp_pelanggan'] ?>" target="_blank" class="btn btn-success btn-sm">WA</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

</div>
<!-- End of Main Content -->